import React, { useMemo, useState } from 'react'
import MapView from './components/MapView'
import Filters from './components/Filters'
import listingsData from './data/listings'

export default function App() {
  const [filters, setFilters] = useState({
    query: '',
    minPrice: 0,
    maxPrice: 10000,
    types: { apartment: true, house: true, studio: true }
  })
  const [sort, setSort] = useState('none') // 'none' | 'price-asc' | 'price-desc'

  const filtered = useMemo(() => {
    return listingsData.filter(l => {
      if (!filters.types[l.type]) return false
      if (l.price < filters.minPrice || l.price > filters.maxPrice) return false
      if (filters.query && !(`${l.title} ${l.description}`.toLowerCase().includes(filters.query.toLowerCase()))) return false
      return true
    })
  }, [filters])

  const sorted = useMemo(() => {
    if (sort === 'price-asc') return [...filtered].sort((a, b) => a.price - b.price)
    if (sort === 'price-desc') return [...filtered].sort((a, b) => b.price - a.price)
    return filtered
  }, [filtered, sort])

  return (
    <div className="app">
      <header className="header">
        <h1>Платформа аренды</h1>
      </header>
      <main className="layout">
        <aside className="sidebar">
          <Filters filters={filters} setFilters={setFilters} sort={sort} setSort={setSort} />
          <div className="listings">
            {sorted.map(item => (
              <article key={item.id} className="card">
                <img src={item.image} alt="" />
                <div className="card-body">
                  <h3>{item.title}</h3>
                  <p className="muted">{item.type} — {item.bedrooms} сп.</p>
                  <p className="price">{item.price} ₽/мес</p>
                </div>
              </article>
            ))}
            {filtered.length === 0 && <p>Ничего не найдено по фильтру.</p>}
          </div>
        </aside>
        <section className="map-area">
          <MapView listings={sorted.length ? sorted : listingsData} />
        </section>
      </main>
    </div>
  )
}
