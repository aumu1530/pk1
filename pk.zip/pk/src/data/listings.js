const listings = [
  {
    id: 1,
    title: 'Светлая 2-комнатная в центре',
    price: 45000,
    type: 'apartment',
    bedrooms: 2,
    lat: 55.7522,
    lng: 37.6156,
    description: 'Рядом метро, балкон, современный ремонт.',
    image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=60'
  },
  {
    id: 2,
    title: 'Уютный дом с садом',
    price: 80000,
    type: 'house',
    bedrooms: 4,
    lat: 55.7645,
    lng: 37.5800,
    description: 'Тихий район, большой участок, парковка.',
    image: 'https://images.unsplash.com/photo-1600607681958-3c0c99a0d4d8?w=800&q=60'
  },
  {
    id: 3,
    title: 'Современная студия',
    price: 30000,
    type: 'studio',
    bedrooms: 1,
    lat: 55.7400,
    lng: 37.6200,
    description: 'Идеально для одного человека, мебель включена.',
    image: 'https://images.unsplash.com/photo-1554995207-c18c203602cb?w=800&q=60'
  }
  ,
  {
    id: 4,
    title: 'Трёшка с видом на парк',
    price: 55000,
    type: 'apartment',
    bedrooms: 3,
    lat: 55.7550,
    lng: 37.6205,
    description: 'Светлая, много мебели, рядом парк.',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=60'
  },
  {
    id: 5,
    title: 'Квартира-студия в новом доме',
    price: 28000,
    type: 'apartment',
    bedrooms: 1,
    lat: 55.7480,
    lng: 37.6100,
    description: 'Новый ремонт, стеклопакеты, консьерж.',
    image: 'https://images.unsplash.com/photo-1505691723518-36a0a0fabf2b?w=800&q=60'
  },
  {
    id: 6,
    title: 'Большая квартира для семьи',
    price: 90000,
    type: 'apartment',
    bedrooms: 4,
    lat: 55.7700,
    lng: 37.6300,
    description: 'Рядом школа и детский сад, просторные комнаты.',
    image: 'https://images.unsplash.com/photo-1494526585095-c41746248156?w=800&q=60'
  },
  {
    id: 7,
    title: 'Модная двухкомнатная',
    price: 47000,
    type: 'apartment',
    bedrooms: 2,
    lat: 55.7600,
    lng: 37.6000,
    description: 'Стильный ремонт, быстрый интернет, рядом метро.',
    image: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=60'
  },
  {
    id: 8,
    title: 'Небольшая, но уютная квартира',
    price: 32000,
    type: 'apartment',
    bedrooms: 1,
    lat: 55.7420,
    lng: 37.6250,
    description: 'Отличный вариант для молодого специалиста.',
    image: 'https://images.unsplash.com/photo-1501183638710-841dd1904471?w=800&q=60'
  }
]

export default listings
