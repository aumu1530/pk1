import React from 'react'

export default function Filters({ filters, setFilters, sort, setSort }) {
  const onTypeChange = (type) => {
    setFilters({ ...filters, types: { ...filters.types, [type]: !filters.types[type] } })
  }

  const resetFilters = () => {
    setFilters({ query: '', minPrice: 0, maxPrice: 200000, types: { apartment: true, house: true, studio: true } })
  }

  const showAll = () => {
    setFilters({ query: '', minPrice: 0, maxPrice: 200000, types: { apartment: true, house: true, studio: true } })
  }

  const saveSearch = () => {
    // placeholder: можно интегрировать сохранение на бэкенде
    alert('Поиск сохранён (пример)')
  }

  return (
    <div className="filters">
      <input
        className="search"
        placeholder="Поиск: район, описание..."
        value={filters.query}
        onChange={e => setFilters({ ...filters, query: e.target.value })}
      />

      <div className="price-range">
        <label>Цена: {filters.minPrice} — {filters.maxPrice} ₽</label>
        <div className="range-inputs">
          <input type="range" min="0" max="200000" value={filters.minPrice} onChange={e => setFilters({ ...filters, minPrice: Number(e.target.value) })} />
          <input type="range" min="0" max="200000" value={filters.maxPrice} onChange={e => setFilters({ ...filters, maxPrice: Number(e.target.value) })} />
        </div>
      </div>

      <div className="types">
        <label>
          <input type="checkbox" checked={filters.types.apartment} onChange={() => onTypeChange('apartment')} /> Квартира
        </label>
        <label>
          <input type="checkbox" checked={filters.types.house} onChange={() => onTypeChange('house')} /> Дом
        </label>
        <label>
          <input type="checkbox" checked={filters.types.studio} onChange={() => onTypeChange('studio')} /> Студия
        </label>
      </div>

      <div className="action-row">
        <button className="btn btn-ghost" onClick={showAll}>Показать все</button>
        <button className="btn" onClick={resetFilters}>Сбросить</button>
        <button className="btn btn-primary" onClick={saveSearch}>Сохранить поиск</button>
        <button
          className="btn btn-outline"
          onClick={() => {
            if (setSort) {
              if (sort === 'none') setSort('price-asc')
              else if (sort === 'price-asc') setSort('price-desc')
              else setSort('none')
            }
          }}
        >{sort === 'none' ? 'Сортировка: по цене' : sort === 'price-asc' ? 'Цена ↑' : 'Цена ↓'}</button>
        <button className="btn btn-ghost" onClick={() => alert('Переключить вид: карта/список (пример)')}>Карта/Список</button>
      </div>
    </div>
  )
}
