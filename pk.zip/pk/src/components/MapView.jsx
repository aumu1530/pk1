import React from 'react'
import { MapContainer, TileLayer, Marker, Popup, CircleMarker } from 'react-leaflet'

export default function MapView({ listings }) {
  const center = listings.length ? [listings[0].lat, listings[0].lng] : [55.76, 37.64]
  return (
    <MapContainer center={center} zoom={11} style={{ height: '100%', width: '100%' }}>
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {listings.map(l => (
        <CircleMarker key={l.id} center={[l.lat, l.lng]} radius={8} pathOptions={{ color: '#ff6b6b' }}>
          <Popup>
            <strong>{l.title}</strong>
            <div>{l.type} — {l.bedrooms} сп.</div>
            <div className="muted">{l.price} ₽/мес</div>
          </Popup>
        </CircleMarker>
      ))}
    </MapContainer>
  )
}
